<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Головна</title>
	<link rel="stylesheet" type="text/css" href="styles/css-main/styles.css">
	<link rel="stylesheet" type="text/css" href="styles/common-css/full-styling.css">
	<link rel="stylesheet" type="text/css" href="styles/common-css/normalize.css">
	<link rel="stylesheet" type="text/css" href="styles/common-css/header.css">
	<link rel="stylesheet" type="text/css" href="styles/common-css/footer.css">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
</head>
<body>
	<section class="header">
        <div class="header-logo-wrapper">
			<img src="main/img/logo.png" class="logo">
		</div>
		<div class="header-container">
            <a class="menu-block" href="../main/main-page.html">
                <div class="menu-line">Головна</div> 
            </a>
            <a class="menu-block" href="containers/baking-page.html">
                <div class="menu-line">Випічка</div>
			</a>
            <a class="menu-block" href="cabinet/cabinet-page.html">
                <div class="menu-line">Особистий кабінет</div> 
            </a>	
		</div>
		<div class="header-basket-wrapper">
			<a href="basket/basket-page.html"><img src="main/img/basket.png"></a>
		</div>
	</section>

	<section class="main-part">
		<div class="part-1-wrapper">
			<div class="block-title">
				<div class="block-title-text">Трохи про нашу пекарню</div>
				<hr/>
			</div>
			<div class="part-1">
				<div class="part-1-text">Ми випікаємо хліб з натуральних продуктів,
					виключаючи маргарин і консерванти. Кожен виріб - політ фантазії
					пекаря, який при цьому вміщає в себе любов і турботу про людину.<br>
					<div class="undisplayed-text">В нашій пекарні ми використовуємо найсучасніше обладнання та
						найдосвіченіших пекарів, саме тому наша випічка є однією з найкращіх
						на ринку.</div>
				</div>
				<img src="main/img/img1.png">
			</div>
		</div>
		<div class="part-2-wrapper">
			<div class="block-title">
				<div class="block-title-text">Ми виготовляємо 3 типи випічки:</div>
				<hr/>
			</div>
			<div class="part-2">
				<a href="containers/container-bread.html"><img src="main/img/img2.png"></a>
				<a href="containers/container-croissants.html"><img src="main/img/img3.png"></a>
				<a href="containers/container-snakes.html"><img src="main/img/img4.png"></a>
			</div>
		</div>
		<div class="part-3-wrapper">
			<div class="block-title">
				<div class="block-title-text">Діючі пропозиції і акції:</div>
				<hr/>
			</div>
			<div class="part-3">
				<div class="part-3-block">
					<img src="main/img/img5.png">
					<div class="part-3-text">При замовленні від 3х товарів<br/>доставка безкоштовна</div>
				</div>
				<div class="part-3-block">
					<img src="main/img/img6.png">
					<div class="part-3-text">При замовленні трьох круасанів<br/>четвертий у подарунок!</div>
				</div>
				<div class="part-3-block">
					<img src="main/img/img7.png">
					<div class="part-3-text">При замовленні снеків на суму від<br/>150 грн ви отримуєте 100 бонусів</div>
				</div>
			</div>
		</div>	
	</section>
	
    <section class="footer">
		<div class="footer-wrapper">
			<div class="contacts">
				<div class="footer-main-line">Наші контакти</div>
				<hr/>
				<div class="footer-line-wrapper">
                    <div class="footer-line-contacts">
                        <div class="footer-none">Наша адреса:</div>Київ, пр. Лесі Українки 28
                    </div>
					<hr/>
					<div class="footer-line-contacts">
                        <div class="footer-none">Email:</div>hlibna_nasoloda@ua.com</div>
					<hr/>
					<div class="footer-line-contacts">
                        <div class="footer-none">Телефон:</div>+38 (099) 361-95-33
                    </div>
				</div>
			</div>
			<div class="navigation">
				<div class="footer-main-line">Навігація</div>
				<hr/>
				<div class="footer-line-wrapper">
					<div class="footer-line-navigation"><a href="../main/main-page.html">Головна</a></div>
					<hr/>
					<div class="footer-line-navigation"><a href="containers/baking-page.html">Випічка</a></div>
					<hr/>
					<div class="footer-line-navigation"><a href="basket/basket-page.html">Кошик</a></div>
					<hr/>
					<div class="footer-line-navigation"><a href="cabinet/cabinet-page.html">Особистий кабінет</a></div>
				</div>
			</div>
		</div>
		<div class="footer-rights-reserved">2020 Хлібна Насолода<br/>Всі права захищені</div>
    </section>
</body>
</html>